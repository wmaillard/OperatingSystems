William Maillard
Program 3
CS 344
5/18/16

To compile the code just type 'make'.  To run it type './smallsh' .